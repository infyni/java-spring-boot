package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWithJpaDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWithJpaDataApplication.class, args);
	}

}
