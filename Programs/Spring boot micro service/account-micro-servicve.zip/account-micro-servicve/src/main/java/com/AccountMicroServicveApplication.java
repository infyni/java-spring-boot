package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccountMicroServicveApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccountMicroServicveApplication.class, args);
	}

}
